// RequesterDashboard.js – PHP/MySQL Backend Version

(function () {
    'use strict';

    // ─── Config ──────────────────────────────────────────────────────────────
    const API_BASE = '../api';   // PHP api/ folder, one level up from helpdesktry/

    // ─── Constants ───────────────────────────────────────────────────────────
    const TICKET_STATUS = { PENDING: 'PENDING', ONGOING: 'ONGOING', COMPLETED: 'COMPLETED' };
    const PRIORITY      = { LOW: 'Low', MEDIUM: 'Medium', HIGH: 'High', CRITICAL: 'Critical' };
    const ACTIVITY_TYPES = {
        TICKET_CREATED:       'ticket_created',
        STATUS_CHANGED:       'status_changed',
        FOLLOWUP_ADDED:       'followup_added',
        TECHNICIAN_ASSIGNED:  'technician_assigned',
        APPROVAL_REQUESTED:   'approval_requested'
    };

    // ─── Auth ────────────────────────────────────────────────────────────────
    let currentUser = null;

    (function checkRequesterAuth() {
        const raw = sessionStorage.getItem('currentUser');
        if (!raw) { window.location.replace('Login.html'); return; }
        try {
            currentUser = JSON.parse(raw);
        } catch (e) {
            sessionStorage.removeItem('currentUser');
            window.location.replace('Login.html');
            return;
        }
        if (currentUser.role !== 'requester') {
            window.location.replace('Dashboard.html');
        }
    })();

    const USER_ID = currentUser ? (currentUser.id || currentUser.user_id) : null;

    // ─── State ───────────────────────────────────────────────────────────────
    let isInitialized    = false;
    let currentFilter    = 'all';
    let requesterTickets = [];
    let activitiesFeed   = [];
    let notifications    = [];

    // ─── SLA state (updated by updateSLAPreview) ──────────────────────────────
    let _currentSLA = { priority: 'Low', response_hours: 8, resolution_hours: 48 };

    // ─── My Requests tab filter ───────────────────────────────────────────────
    let myRequestsTabFilter = 'all';

    // ─── Resolve / Feedback state ─────────────────────────────────────────────
    let pendingResolveId    = null;
    let pendingFeedbackId   = null;
    let selectedStarRating  = 0;

    // ─── PHP API helper ───────────────────────────────────────────────────────
    async function apiFetch(path, options = {}) {
        try {
            const res = await fetch(`${API_BASE}${path}`, {
                headers: { 'Content-Type': 'application/json' },
                ...options
            });
            const json = await res.json();
            // FIX: don't discard the backend's real message on non-2xx responses.
            if (!res.ok) {
                console.error('API error:', json?.message || `HTTP ${res.status}`);
                return json ?? { success: false, message: `HTTP ${res.status}` };
            }
            return json;
        } catch (err) {
            console.error('API error:', err.message);
            return { success: false, message: 'Network error or invalid server response.' };
        }
    }

    // ─── Data loaders (PHP backend) ───────────────────────────────────────────

    async function loadTickets() {
        const json = await apiFetch(`/get_my_tickets.php?requester_id=${USER_ID}`);
        if (json && json.success && json.data) {
            requesterTickets = json.data.map(t => ({
                id:            t.ticket_code,
                request_id:    t.id,
                title:         t.title,
                priority:      t.priority,
                status:        t.status,
                approvalStatus: t.approval_status || 'Not Required',
                rejectionNote:  t.rejection_note || '',
                date:          t.submitted_at ? t.submitted_at.slice(0, 10) : '',
                requester:     currentUser.name || 'Requester',
                category:      t.category,
                department:    t.department,
                equipmentItem: t.equipment_item,
                requestType:   t.request_type,
                location:      t.location || '',
                description:   t.description || '',
                conversations: (t.conversations || []).map(c => ({
                    author_name:  c.author_name,
                    message_text: c.message,
                    created_at:   c.created_at,
                    isRequester:  !!c.is_requester
                }))
            }));
        } else {
            requesterTickets = [];
        }
    }

    async function loadActivities() {
        // Built from ticket data — no separate PHP endpoint needed
        activitiesFeed = requesterTickets.slice(0, 10).map(t => ({
            id:          t.request_id,
            type:        ACTIVITY_TYPES.TICKET_CREATED,
            title:       `Request ${t.id} — ${t.status}`,
            description: t.title,
            time:        formatRelativeTime(t.date),
            ticketId:    t.id,
            priority:    t.priority,
            status:      t.status
        }));
    }

    async function loadNotifications() {
        // Built from recent tickets — no separate PHP endpoint needed
        notifications = requesterTickets.slice(0, 5).map(t => ({
            id:      t.request_id,
            title:   `Ticket ${t.id}`,
            message: `"${t.title}" is ${t.status}`,
            time:    formatDate(t.date),
            icon:    'fa-ticket-alt',
            read:    false
        }));
    }

    async function loadStats() {
        const total     = requesterTickets.length;
        const pending   = requesterTickets.filter(t => t.status === 'Pending').length;
        const ongoing   = requesterTickets.filter(t => t.status === 'Ongoing').length;
        const completed = requesterTickets.filter(t => t.status === 'Completed').length;
        const closed    = requesterTickets.filter(t => t.status === 'Closed').length;
        const set = (id, val) => { const el = document.getElementById(id); if (el) el.innerText = val; };
        set('totalRequests',  total);
        set('pendingCount',   pending);
        set('ongoingCount',   ongoing);
        set('completedCount', completed);
        set('closedCount',    closed);
    }

    async function loadDepartments() {
        const json = await apiFetch('/get_departments.php');
        if (!json || !json.success) return;
        const select = document.getElementById('department');
        if (!select) return;
        select.innerHTML = '<option value="">Select department</option>';
        json.data.forEach(dept => {
            const opt       = document.createElement('option');
            opt.value       = dept.id;        // numeric DB id — sent as department_id
            opt.textContent = dept.name;
            select.appendChild(opt);
        });
    }

    // ─── SLA auto-preview ─────────────────────────────────────────────────────
    async function updateSLAPreview() {
        const category  = document.getElementById('category')?.value   || '';
        const reqType   = document.getElementById('requestType')?.value || '';
        const equipment = document.getElementById('equipmentItem')?.value || '';
        const display   = document.getElementById('priorityDisplay');

        if (!category || !reqType) {
            _currentSLA = { priority: 'Low', response_hours: 8, resolution_hours: 48 };
            if (display) { display.innerText = 'Low'; display.className = 'priority-badge-large low'; }
            return;
        }

        const json = await apiFetch('/get_sla.php', {
            method: 'POST',
            body:   JSON.stringify({ category, request_type: reqType, equipment })
        });

        if (json && json.success) {
            _currentSLA = json.sla;
            if (display) {
                display.innerText = json.sla.priority;
                display.className = `priority-badge-large ${json.sla.priority.toLowerCase()}`;
            }
            // Show SLA preview section
            const slaSection = document.getElementById('slaPreviewSection');
            if (slaSection) {
                slaSection.style.display = 'block';
                const fmtHours = h => h < 1 ? `${Math.round(h * 60)} min` : `${h} hour${h > 1 ? 's' : ''}`;
                const resp = document.getElementById('slaResponsePreview');
                const reso = document.getElementById('slaResolutionPreview');
                if (resp) resp.textContent = fmtHours(json.sla.response_hours);
                if (reso) reso.textContent = fmtHours(json.sla.resolution_hours);
            }
        }
    }

    // Keep calculatePriority so existing event listeners still work
    function calculatePriority() {
        updateSLAPreview();
        return _currentSLA.priority;
    }

    // ─── Submit new request ───────────────────────────────────────────────────
    async function handleFormSubmit(e) {
        e.preventDefault();
        const category    = document.getElementById('category')?.value    || '';
        const department  = document.getElementById('department')?.value  || '';
        const equipItem   = document.getElementById('equipmentItem')?.value.trim() || '';
        const requestType = document.getElementById('requestType')?.value || '';
        const title       = document.getElementById('requestTitle')?.value.trim() || '';
        const description = document.getElementById('description')?.value.trim() || '';
        const location    = document.getElementById('location')?.value.trim() || '';
        const prefDate    = document.getElementById('preferredDate')?.value || null;

        if (!category)    { showToast('Please select a category.',        true); return; }
        if (!department)  { showToast('Please select a department.',      true); return; }
        if (!equipItem)   { showToast('Please enter an equipment/item.',  true); return; }
        if (!requestType) { showToast('Please select a request type.',    true); return; }
        if (!title)       { showToast('Please enter a request title.',    true); return; }

        const payload = {
            requester_id:   USER_ID,
            requester_name: currentUser.name || 'Requester',
            department_id:  department,        // numeric id from loadDepartments()
            title,
            description,
            category,
            request_type:   requestType,
            equipment_item: equipItem,
            location,
            preferred_date: prefDate
        };

        const data = await apiFetch('/submit_ticket.php', {
            method: 'POST',
            body:   JSON.stringify(payload)
        });

        if (!data || !data.success) {
            showToast('Submission failed: ' + (data?.message || 'Unknown error'), true);
            return;
        }

        const deptSelect = document.getElementById('department');
        const deptName   = deptSelect?.options[deptSelect.selectedIndex]?.text || department;
        closeRequestModal();

        // FIX 1: Equipment/Consumable requests need Dept Head approval — show the
        // approval notice instead of the normal "submitted" confirmation.
        if (data.needs_approval) {
            showApprovalNotice(data.ticket_code, title, data.priority, deptName);
        } else {
            showConfirmationModal(data.ticket_code, title, data.priority, deptName);
        }
        showToast(`✓ Request ${data.ticket_code} submitted successfully!`);
        await refreshAllData();
    }

    // FIX 1: Approval-required notice — reuses the confirmation modal and injects
    // a warning banner explaining the request is pending Department Head review.
    function showApprovalNotice(ticketCode, title, priority, department) {
        const modal = document.getElementById('confirmationModal');
        if (!modal) return;

        const set = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
        set('confirmTicketId', ticketCode);
        set('confirmTitle',    title);
        set('confirmPriority', priority);
        set('confirmDept',     department);
        set('confirmDate',     new Date().toLocaleDateString('en-PH', { year: 'numeric', month: 'long', day: 'numeric' }));

        let banner = document.getElementById('approvalNoticeBanner');
        if (!banner) {
            const summaryCard = modal.querySelector('.request-summary-card');
            if (summaryCard) {
                banner = document.createElement('div');
                banner.id = 'approvalNoticeBanner';
                banner.className = 'approval-notice-banner';
                banner.innerHTML = `
                    <i class="fas fa-exclamation-triangle"></i>
                    <div>
                        <strong>Approval Required</strong>
                        <p>This request requires Department Head approval before it can be processed by the IT team.
                        Your Department Head will review and approve this request.</p>
                    </div>`;
                summaryCard.parentNode.insertBefore(banner, summaryCard);
            }
        } else {
            banner.style.display = 'flex';
        }

        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    // ─── Follow-up ────────────────────────────────────────────────────────────
    async function addFollowUp(requestId, ticketNumber) {
        const messageInput = document.getElementById('followUpMessage');
        const message      = messageInput?.value.trim();
        if (!message) { showToast('Please enter a message before sending.', true); return; }

        const data = await apiFetch('/add_followup.php', {
            method: 'POST',
            body:   JSON.stringify({
                ticket_id:   requestId,
                author_id:   USER_ID,
                author_name: currentUser.name || 'Requester',
                message
            })
        });

        if (!data || !data.success) {
            showToast('Could not send follow-up.', true);
            return;
        }

        showToast(`Follow-up added to #${ticketNumber}`);
        messageInput.value = '';

        // Reload tickets then re-open detail to refresh conversation thread
        await loadTickets();
        await showRequestDetail(requestId);
        await loadActivities();
        renderActivityTimeline();
    }

    // ─── Notifications (local only — no separate PHP endpoint) ────────────────
    async function markAllNotificationsRead() {
        notifications.forEach(n => n.read = true);
        renderNotifications();
        showToast('All notifications marked as read.');
    }

    // ─── Full UI refresh ──────────────────────────────────────────────────────
    async function refreshAllData() {
        await loadTickets();
        await Promise.all([loadActivities(), loadStats()]);
        renderTicketsPanel();
        renderActivityTimeline();
        const fullListModal = document.getElementById('fullListModal');
        if (fullListModal && fullListModal.classList.contains('active')) {
            renderFilteredTicketsInModal();
        }
    }

    // ─── Detail modal ─────────────────────────────────────────────────────────
    // ─── Full list modal ──────────────────────────────────────────────────────
    function renderFilteredTicketsInModal() {
        const gridContainer   = document.getElementById('allTicketsGrid');
        const resultsCountSpan = document.getElementById('resultsCount');
        if (!gridContainer) return;

        let filtered = [...requesterTickets];
        if (currentFilter !== 'all') {
            filtered = filtered.filter(t => t.status === currentFilter);
        }
        filtered.sort((a, b) => new Date(b.date) - new Date(a.date));

        if (resultsCountSpan) resultsCountSpan.innerText = `${filtered.length} request${filtered.length !== 1 ? 's' : ''}`;

        if (filtered.length === 0) {
            gridContainer.innerHTML = '<div class="empty-state"><i class="fas fa-inbox" style="font-size:2rem;margin-bottom:12px;display:block;"></i>No requests match the selected filter.</div>';
            return;
        }

        gridContainer.innerHTML = filtered.map(t => {
            const disp = getDisplayStatus(t);
            return `
            <div class="ticket-item ${getPriorityClass(t.priority)}" data-request-id="${t.request_id}" data-status="${t.status}">
                <div class="ticket-id">#${escapeHtml(t.id)}<span class="priority-badge ${getPriorityBadgeClass(t.priority)}">${escapeHtml(t.priority)}</span></div>
                <div class="ticket-desc">${escapeHtml(t.title)}</div>
                <div class="ticket-meta">Status: ${escapeHtml(disp.label)} · ${formatDate(t.date)} · ${escapeHtml(t.department || 'N/A')}</div>
            </div>
        `;
        }).join('');

        gridContainer.querySelectorAll('.ticket-item').forEach(el => {
            el.addEventListener('click', () => {
                const reqId = Number(el.dataset.requestId);
                closeFullListModal();
                setTimeout(() => showRequestDetail(reqId), 200);
            });
        });
    }

    function setupFilterButtons() {
        document.querySelectorAll('#ticketFilterBar .filter-chip').forEach(chip => {
            chip.addEventListener('click', () => {
                currentFilter = chip.dataset.filter;
                document.querySelectorAll('#ticketFilterBar .filter-chip').forEach(c => c.classList.remove('filter-chip-active'));
                chip.classList.add('filter-chip-active');
                renderFilteredTicketsInModal();
            });
        });
    }

    function openFullListModal() {
        const fullModal = document.getElementById('fullListModal');
        if (!fullModal) return;
        currentFilter = 'all';
        document.querySelectorAll('#ticketFilterBar .filter-chip').forEach(c => {
            c.classList.toggle('filter-chip-active', c.dataset.filter === 'all');
        });
        renderFilteredTicketsInModal();
        fullModal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    function closeFullListModal() {
        const fullModal = document.getElementById('fullListModal');
        if (fullModal) { fullModal.classList.remove('active'); document.body.style.overflow = ''; }
    }

    // ─── Modal helpers ────────────────────────────────────────────────────────
    function openRequestModal() {
        const modal = document.getElementById('newRequestModal');
        if (modal) { modal.classList.add('active'); document.body.style.overflow = 'hidden'; calculatePriority(); }
    }

    function closeRequestModal() {
        const modal = document.getElementById('newRequestModal');
        if (modal) { modal.classList.remove('active'); document.body.style.overflow = ''; document.getElementById('serviceRequestForm')?.reset(); calculatePriority(); }
    }

    function closeConfirmationModal() {
        const modal = document.getElementById('confirmationModal');
        if (modal) { modal.classList.remove('active'); document.body.style.overflow = ''; }
    }

    function closeDetailModal() {
        const modal = document.getElementById('requestDetailModal');
        if (modal) { modal.classList.remove('active'); document.body.style.overflow = ''; }
    }

    function showConfirmationModal(ticketId, title, priority, department) {
        const modal = document.getElementById('confirmationModal');
        if (!modal) return;
        const set = (id, val) => { const el = document.getElementById(id); if (el) el.innerText = val; };
        set('confirmTicketId', ticketId);
        set('confirmTitle',    title);
        set('confirmPriority', priority);
        set('confirmDept',     department);
        set('confirmDate',     new Date().toLocaleString());
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }

    // ─── Profile dropdown & dark mode ─────────────────────────────────────────
    // ─── Apply user info to page elements ───────────────────────────────────────
    function applyUserInfo() {
        const name = currentUser?.name || 'Requester';
        const dept = currentUser?.department || '';
        const el = document.getElementById('profileDisplayName');
        if (el) el.textContent = dept ? `${name} (${dept})` : name;
        const wn = document.getElementById('welcomeFirstName');
        if (wn) wn.textContent = name.split(' ')[0];
    }

    function initProfileDropdown() {
        const profileDropdown = document.getElementById('profileDropdown');
        const profileBtn      = document.getElementById('profileBtn');
        const themeSwitch     = document.getElementById('themeSwitchCheckbox');
        const logoutBtn       = document.getElementById('logoutBtn');

        if (profileBtn && profileDropdown) {
            profileBtn.addEventListener('click', e => { e.stopPropagation(); profileDropdown.classList.toggle('open'); });
            document.addEventListener('click', e => { if (!profileDropdown.contains(e.target)) profileDropdown.classList.remove('open'); });
        }

        if (themeSwitch) {
            const isDark = localStorage.getItem('theme') === 'dark';
            themeSwitch.checked = isDark;
            if (isDark) { document.body.classList.add('dark-mode'); const icon = document.getElementById('themeIcon'); if (icon) icon.className = 'fas fa-sun'; }
            themeSwitch.addEventListener('change', e => {
                const dark = e.target.checked;
                document.body.classList.toggle('dark-mode', dark);
                localStorage.setItem('theme', dark ? 'dark' : 'light');
                const icon = document.getElementById('themeIcon');
                if (icon) icon.className = dark ? 'fas fa-sun' : 'fas fa-moon';
                showToast(dark ? 'Dark mode activated.' : 'Light mode activated.');
            });
        }

        if (logoutBtn) {
            logoutBtn.addEventListener('click', () => {
                showToast('Logging out…');
                setTimeout(() => { sessionStorage.removeItem('currentUser'); window.location.href = 'Login.html'; }, 800);
            });
        }
    }

    // ─── Wire all event listeners ─────────────────────────────────────────────
    function setupEventListeners() {
        document.getElementById('openNewRequestBtn')?.addEventListener('click', openRequestModal);
        document.getElementById('closeModalBtn')?.addEventListener('click',    closeRequestModal);
        document.getElementById('cancelFormBtn')?.addEventListener('click',    closeRequestModal);
        document.getElementById('newRequestModal')?.addEventListener('click', e => { if (e.target === document.getElementById('newRequestModal')) closeRequestModal(); });

        document.getElementById('serviceRequestForm')?.addEventListener('submit', handleFormSubmit);
        document.getElementById('category')?.addEventListener('change',    updateSLAPreview);
        document.getElementById('requestType')?.addEventListener('change', updateSLAPreview);
        document.getElementById('equipmentItem')?.addEventListener('input', updateSLAPreview);

        document.getElementById('modalDoneBtn')?.addEventListener('click',      closeConfirmationModal);
        document.getElementById('modalNewRequestBtn')?.addEventListener('click', () => { closeConfirmationModal(); openRequestModal(); });
        document.getElementById('confirmationModal')?.addEventListener('click', e => { if (e.target === document.getElementById('confirmationModal')) closeConfirmationModal(); });

        document.getElementById('closeDetailModalBtn')?.addEventListener('click', closeDetailModal);
        document.getElementById('requestDetailModal')?.addEventListener('click', e => { if (e.target === document.getElementById('requestDetailModal')) closeDetailModal(); });

        // Notifications
        const bell  = document.getElementById('notificationBell');
        const panel = document.getElementById('notificationPanel');
        const wrap  = document.getElementById('notificationWrapper');
        if (bell && panel) {
            bell.addEventListener('click', e => { e.stopPropagation(); panel.classList.toggle('open'); });
            document.addEventListener('click', e => { if (wrap && !wrap.contains(e.target)) panel.classList.remove('open'); });
        }
        document.getElementById('markAllReadBtn')?.addEventListener('click', markAllNotificationsRead);

        // View All tickets
        document.getElementById('viewAllTicketsLink')?.addEventListener('click', e => { e.preventDefault(); openFullListModal(); });
        document.getElementById('closeFullListBtn')?.addEventListener('click', closeFullListModal);
        document.getElementById('fullListModal')?.addEventListener('click', e => { if (e.target === document.getElementById('fullListModal')) closeFullListModal(); });

        // Escape key
        document.addEventListener('keydown', e => {
            if (e.key !== 'Escape') return;
            if (document.getElementById('newRequestModal')?.classList.contains('active'))   closeRequestModal();
            if (document.getElementById('confirmationModal')?.classList.contains('active'))  closeConfirmationModal();
            if (document.getElementById('requestDetailModal')?.classList.contains('active')) closeDetailModal();
            if (document.getElementById('fullListModal')?.classList.contains('active'))      closeFullListModal();
            document.getElementById('notificationPanel')?.classList.remove('open');
            document.getElementById('profileDropdown')?.classList.remove('open');
        });
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────
    function formatDate(dateStr) {
        if (!dateStr) return 'N/A';
        try { return new Date(dateStr).toLocaleDateString(undefined, { year:'numeric', month:'short', day:'numeric' }); }
        catch (e) { return dateStr; }
    }

    function formatRelativeTime(dateStr) {
        if (!dateStr) return '';
        const diff = Date.now() - new Date(dateStr).getTime();
        const mins = Math.floor(diff / 60000);
        if (mins < 1)  return 'Just now';
        if (mins < 60) return `${mins} min${mins > 1 ? 's' : ''} ago`;
        const hrs = Math.floor(mins / 60);
        if (hrs < 24)  return `${hrs} hour${hrs > 1 ? 's' : ''} ago`;
        const days = Math.floor(hrs / 24);
        if (days < 7)  return `${days} day${days > 1 ? 's' : ''} ago`;
        return formatDate(dateStr);
    }

    function escapeHtml(str) {
        if (!str) return '';
        return String(str).replace(/[&<>"']/g, m => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[m]));
    }

    function getPriorityClass(p) {
        return { Critical:'priority-critical', High:'priority-high', Medium:'priority-medium', Low:'priority-low' }[p] || 'priority-low';
    }

    function getPriorityBadgeClass(p) {
        return { Critical:'critical', High:'high', Medium:'medium', Low:'low' }[p] || 'low';
    }

    function getStatusClass(s) {
        const lc = (s || '').toLowerCase();
        if (lc === 'pending')               return 'status-pending';
        if (lc === 'ongoing')               return 'status-ongoing';
        if (lc === 'completed')             return 'status-completed';
        // FIX 3: requester must see "awaiting your confirmation" as its own state,
        // not silently fall back to Pending.
        if (lc === 'pending confirmation')  return 'status-pending-confirmation';
        if (lc === 'closed')                return 'status-closed';
        return 'status-pending';
    }

    // FIX: a ticket closed because the Dept Head rejected it should read
    // "Rejected" to the requester, not a bare "Closed" — same underlying
    // status column, different label/class so it's clear what happened.
    function getDisplayStatus(ticket) {
        if (ticket.status === 'Closed' && ticket.approvalStatus === 'Rejected') {
            return { label: 'Rejected', cls: 'status-rejected' };
        }
        return { label: ticket.status, cls: getStatusClass(ticket.status) };
    }

    function showToast(message, isError = false) {
        const toast = document.getElementById('toastMsg');
        if (!toast) return;
        toast.textContent = message;
        toast.style.background = isError ? '#c62828' : '#2c4c6e';
        toast.classList.add('show');
        clearTimeout(toast._timer);
        toast._timer = setTimeout(() => toast.classList.remove('show'), 2800);
    }

    // ─── Render: tickets panel ────────────────────────────────────────────────
    function renderTicketsPanel() {
        const container = document.getElementById('myTicketsList');
        if (!container) return;

        let filtered = [...requesterTickets];
        if (myRequestsTabFilter !== 'all') {
            filtered = filtered.filter(t => t.status === myRequestsTabFilter);
        }
        const sorted = filtered.sort((a, b) => new Date(b.date) - new Date(a.date));
        const recent = sorted.slice(0, 6);

        if (recent.length === 0) {
            container.innerHTML = `<div class="empty-state"><i class="fas fa-inbox" style="font-size:2rem;color:#dee4ea;margin-bottom:12px;display:block;"></i>No ${myRequestsTabFilter === 'all' ? '' : myRequestsTabFilter + ' '}requests yet.</div>`;
            return;
        }

        container.innerHTML = recent.map(t => {
            const disp = getDisplayStatus(t);
            return `
            <div class="ticket-item ${getPriorityClass(t.priority)}" data-request-id="${t.request_id}">
                <div class="ticket-id">#${escapeHtml(t.id)}<span class="priority-badge ${getPriorityBadgeClass(t.priority)}">${escapeHtml(t.priority)}</span></div>
                <div class="ticket-desc">${escapeHtml(t.title)}</div>
                <div class="ticket-meta">
                    <span class="status-chip ${disp.cls}">${escapeHtml(disp.label)}</span>
                    &nbsp;·&nbsp;${formatDate(t.date)}
                </div>
            </div>`;
        }).join('');

        container.querySelectorAll('.ticket-item[data-request-id]').forEach(el => {
            el.addEventListener('click', () => showRequestDetail(Number(el.dataset.requestId)));
        });
    }

    // ─── Render: activity timeline ────────────────────────────────────────────
    function renderActivityTimeline() {
        const container = document.getElementById('activitiesFeed');
        if (!container) return;
        if (activitiesFeed.length === 0) {
            container.innerHTML = '<div class="empty-state">No recent activity.</div>'; return;
        }
        container.innerHTML = activitiesFeed.map(a => `
            <div class="timeline-item">
                <div class="timeline-icon"><i class="fas fa-ticket-alt"></i></div>
                <div class="timeline-content">
                    <div class="timeline-title">${escapeHtml(a.title)}</div>
                    <div class="timeline-description">${escapeHtml(a.description)}</div>
                    <div class="timeline-date">${escapeHtml(a.time)}</div>
                </div>
            </div>`).join('');
    }

    // ─── Render: notifications ────────────────────────────────────────────────
    function renderNotifications() {
        const container = document.getElementById('notificationList');
        const badge     = document.getElementById('notificationBadge');
        const unread    = notifications.filter(n => !n.read).length;

        if (badge) { badge.textContent = unread; badge.style.display = unread > 0 ? 'inline-block' : 'none'; }

        if (!container) return;
        if (notifications.length === 0) {
            container.innerHTML = '<div style="padding:24px;text-align:center;color:#8aa5bf;">No notifications</div>'; return;
        }
        container.innerHTML = notifications.map(n => `
            <div class="notification-item ${!n.read ? 'unread' : ''}" data-id="${n.id}">
                <div class="notif-icon"><i class="fas ${n.icon || 'fa-bell'}"></i></div>
                <div class="notif-content">
                    <p><strong>${escapeHtml(n.title)}</strong><br>${escapeHtml(n.message)}</p>
                    <small>${escapeHtml(n.time)}</small>
                </div>
            </div>`).join('');

        container.querySelectorAll('.notification-item').forEach(el => {
            el.addEventListener('click', () => {
                const id = Number(el.dataset.id);
                const notif = notifications.find(n => Number(n.id) === id);
                if (notif && !notif.read) { notif.read = true; renderNotifications(); }
            });
        });
    }

    // ─── Detail modal ─────────────────────────────────────────────────────────
    async function showRequestDetail(requestId) {
        const modal     = document.getElementById('requestDetailModal');
        const modalBody = document.getElementById('detailModalBody');
        if (!modal || !modalBody) return;

        modalBody.innerHTML = '<div style="padding:40px;text-align:center;color:#8aa5bf;">Loading…</div>';
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';

        const ticket = requesterTickets.find(t => Number(t.request_id) === Number(requestId)) || null;
        if (!ticket) {
            modalBody.innerHTML = '<div style="padding:40px;text-align:center;color:#c62828;">Could not load request details.</div>';
            return;
        }

        const slaDeadline = (ticket.priority === 'High' || ticket.priority === 'Critical')
            ? new Date(new Date(ticket.date).getTime() + 30 * 60000).toLocaleString()
            : 'Within 2 business days';

        const convHtml = ticket.conversations && ticket.conversations.length > 0
            ? ticket.conversations.map(msg => `
                <div class="conversation-message">
                    <div class="message-author">
                        <strong class="author-name">${escapeHtml(msg.author_name)}</strong>
                        <span class="message-timestamp">${formatDate(msg.created_at)}</span>
                    </div>
                    <div class="message-text">${escapeHtml(msg.message_text)}</div>
                </div>`).join('')
            : '<div style="text-align:center;padding:20px;color:#8aa5bf;">No messages yet.</div>';

        // FIX 3: The IT Admin no longer sets status straight to 'Completed' — it
        // goes to 'Pending Confirmation' first (see update_ticket.php send_confirmation
        // action) and only the requester's own confirmation moves it to 'Closed'.
        const resolveBtn = ticket.status === 'Pending Confirmation'
            ? `<button class="btn-confirm-resolve-trigger" id="showResolveConfirmBtn" data-id="${ticket.request_id}" data-code="${escapeHtml(ticket.id)}">
                   <i class="fas fa-check-double"></i> Confirm Issue Resolved
               </button>` : '';

        const disp = getDisplayStatus(ticket);

        // FIX: surface the Dept Head's rejection reason directly on the ticket,
        // not just buried in the conversation feed.
        const rejectionBanner = ticket.approvalStatus === 'Rejected'
            ? `<div class="approval-notice-banner" style="background:#fdeaea;border-color:#e08a8a;">
                   <i class="fas fa-ban" style="color:#c62828;"></i>
                   <div>
                       <strong style="color:#8a1f1f;">Request Rejected</strong>
                       <p style="color:#7a3a3a;">Your Department Head rejected this request and it has been closed.
                       ${ticket.rejectionNote ? `Reason: ${escapeHtml(ticket.rejectionNote)}` : ''}</p>
                   </div>
               </div>`
            : '';

        modalBody.innerHTML = `
            <div class="request-detail-card">
                <div class="request-header">
                    <h2 class="request-title">#${escapeHtml(ticket.id)}: ${escapeHtml(ticket.title)}</h2>
                    <span class="status-badge ${disp.cls}">${escapeHtml(disp.label)}</span>
                </div>
                ${rejectionBanner}
                <div class="info-grid">
                    <div class="info-item"><span class="info-label"><i class="fas fa-calendar"></i> Submitted</span><span class="info-value">${formatDate(ticket.date)}</span></div>
                    <div class="info-item"><span class="info-label"><i class="fas fa-chart-line"></i> Priority</span><span class="info-value">${escapeHtml(ticket.priority)}</span></div>
                    <div class="info-item"><span class="info-label"><i class="fas fa-tag"></i> Category</span><span class="info-value">${escapeHtml(ticket.category || 'N/A')}</span></div>
                    <div class="info-item"><span class="info-label"><i class="fas fa-building"></i> Department</span><span class="info-value">${escapeHtml(ticket.department || 'N/A')}</span></div>
                    <div class="info-item"><span class="info-label"><i class="fas fa-desktop"></i> Equipment/Item</span><span class="info-value">${escapeHtml(ticket.equipmentItem || 'N/A')}</span></div>
                    <div class="info-item"><span class="info-label"><i class="fas fa-map-marker-alt"></i> Location</span><span class="info-value">${escapeHtml(ticket.location || 'Not specified')}</span></div>
                </div>
                <div class="info-item" style="margin-bottom:20px;">
                    <span class="info-label"><i class="fas fa-align-left"></i> Issue Description</span>
                    <span class="info-value">${escapeHtml(ticket.description || 'No description provided.')}</span>
                </div>
                <div class="sla-card">
                    <div class="sla-row"><span class="sla-label"><i class="fas fa-hourglass-half"></i> Expected Resolution</span><span class="sla-value">${(ticket.priority === 'High' || ticket.priority === 'Critical') ? '30 minutes' : '2 business days'}</span></div>
                    <div class="sla-row"><span class="sla-label"><i class="fas fa-clock"></i> SLA Deadline</span><span class="sla-value">${slaDeadline}</span></div>
                </div>
                ${resolveBtn}
            </div>
            <div class="follow-up-section">
                <h4 style="margin-bottom:16px;color:#1a4a6e;"><i class="fas fa-comments"></i> Conversation &amp; Updates</h4>
                <div class="conversation-thread" id="conversationThread">${convHtml}</div>
                <div class="follow-up-input">
                    <textarea id="followUpMessage" rows="2" placeholder="Add additional information or ask a question…"></textarea>
                    <button class="send-followup-btn" id="sendFollowUpBtn"><i class="fas fa-paper-plane"></i> Send</button>
                </div>
            </div>`;

        document.getElementById('sendFollowUpBtn')?.addEventListener('click', () => addFollowUp(ticket.request_id, ticket.id));
        document.getElementById('showResolveConfirmBtn')?.addEventListener('click', () => {
            pendingResolveId = ticket.request_id;
            document.getElementById('resolveTicketCode').textContent = '#' + ticket.id;
            closeDetailModal();
            document.getElementById('resolveConfirmModal')?.classList.add('active');
        });
    }

    // ─── Issue Resolution Confirmation ────────────────────────────────────────
    function initResolveConfirm() {
        document.getElementById('closeResolveModalBtn')?.addEventListener('click', () => {
            document.getElementById('resolveConfirmModal')?.classList.remove('active');
            pendingResolveId = null;
        });

        document.getElementById('confirmResolvedBtn')?.addEventListener('click', async () => {
            if (!pendingResolveId) return;
            const json = await apiFetch('/dept-head-data.php?action=confirm_resolved', {
                method: 'POST',
                body:   JSON.stringify({ ticket_id: pendingResolveId, user_id: USER_ID, user_name: currentUser?.name })
            });
            document.getElementById('resolveConfirmModal')?.classList.remove('active');
            if (json?.success) {
                showToast('Ticket closed. Thank you!');
                pendingFeedbackId = pendingResolveId;
                pendingResolveId  = null;
                await refreshAllData();
                // Show feedback modal after a short delay
                setTimeout(() => {
                    if (pendingFeedbackId) openFeedbackModal(pendingFeedbackId);
                }, 400);
            } else {
                showToast('Could not close ticket: ' + (json?.message || ''), true);
                pendingResolveId = null;
            }
        });

        document.getElementById('reopenTicketBtn')?.addEventListener('click', async () => {
            if (!pendingResolveId) return;
            const json = await apiFetch('/dept-head-data.php?action=reopen_ticket', {
                method: 'POST',
                body:   JSON.stringify({ ticket_id: pendingResolveId, user_id: USER_ID, user_name: currentUser?.name })
            });
            document.getElementById('resolveConfirmModal')?.classList.remove('active');
            pendingResolveId = null;
            if (json?.success) { showToast('Ticket re-opened for IT team.'); await refreshAllData(); }
            else showToast('Could not re-open ticket.', true);
        });
    }

    // ─── Feedback Modal ───────────────────────────────────────────────────────
    function openFeedbackModal(ticketId) {
        const ticket = requesterTickets.find(t => Number(t.request_id) === Number(ticketId));
        const ref    = document.getElementById('feedbackTicketRef');
        if (ref && ticket) {
            ref.innerHTML = `<div class="feedback-ref-row"><i class="fas fa-ticket-alt"></i> <strong>#${escapeHtml(ticket.id)}</strong> — ${escapeHtml(ticket.title)}</div>`;
        }
        selectedStarRating = 0;
        highlightStars(0);
        const countLabel = document.getElementById('starCountLabel');
        if (countLabel) countLabel.textContent = '0 / 5';
        const comment = document.getElementById('feedbackComment');
        if (comment) comment.value = '';
        document.getElementById('feedbackModal')?.classList.add('active');
    }

    function highlightStars(count) {
        document.querySelectorAll('#starRatingRow .star-icon').forEach(s => {
            s.classList.toggle('star-active', Number(s.dataset.value) <= count);
        });
    }

    function initFeedback() {
        document.querySelectorAll('#starRatingRow .star-icon').forEach(star => {
            star.addEventListener('click', () => {
                selectedStarRating = Number(star.dataset.value);
                highlightStars(selectedStarRating);
                const lbl = document.getElementById('starCountLabel');
                if (lbl) lbl.textContent = `${selectedStarRating} / 5`;
            });
            star.addEventListener('mouseenter', () => highlightStars(Number(star.dataset.value)));
            star.addEventListener('mouseleave', () => highlightStars(selectedStarRating));
        });

        document.getElementById('skipFeedbackBtn')?.addEventListener('click', () => {
            document.getElementById('feedbackModal')?.classList.remove('active');
            pendingFeedbackId = null;
        });

        document.getElementById('closeFeedbackModalBtn')?.addEventListener('click', () => {
            document.getElementById('feedbackModal')?.classList.remove('active');
            pendingFeedbackId = null;
        });

        document.getElementById('submitFeedbackBtn')?.addEventListener('click', async () => {
            if (selectedStarRating < 1) { showToast('Please select a star rating.', true); return; }
            if (!pendingFeedbackId) { document.getElementById('feedbackModal')?.classList.remove('active'); return; }
            const comment = document.getElementById('feedbackComment')?.value.trim() || '';
            const json = await apiFetch('/dept-head-data.php?action=submit_feedback', {
                method: 'POST',
                body:   JSON.stringify({ ticket_id: pendingFeedbackId, user_id: USER_ID, rating: selectedStarRating, comment })
            });
            if (json?.success) {
                document.getElementById('feedbackModal')?.classList.remove('active');
                pendingFeedbackId  = null;
                selectedStarRating = 0;
                showToast('Feedback submitted. Thank you!');
            } else {
                showToast('Could not submit feedback.', true);
            }
        });
    }

    // ─── My Requests tab bar ──────────────────────────────────────────────────
    function initMyRequestsTabs() {
        document.querySelectorAll('#requestStatusTabs .req-tab').forEach(tab => {
            tab.addEventListener('click', () => {
                document.querySelectorAll('#requestStatusTabs .req-tab').forEach(t => t.classList.remove('active'));
                tab.classList.add('active');
                myRequestsTabFilter = tab.dataset.status;
                renderTicketsPanel();
            });
        });
    }

    // ─── Initialise ───────────────────────────────────────────────────────────
    async function init() {
        if (isInitialized) return;
        isInitialized = true;

        applyUserInfo();
        initProfileDropdown();
        setupEventListeners();
        setupFilterButtons();
        initMyRequestsTabs();
        initResolveConfirm();
        initFeedback();

        // 1. Load departments into dropdown first
        await loadDepartments();

        // 2. Load tickets — activities & notifications are derived from ticket data
        showToast('Loading your dashboard…');
        await loadTickets();
        await Promise.all([loadActivities(), loadNotifications(), loadStats()]);

        renderTicketsPanel();
        renderActivityTimeline();
        renderNotifications();

        console.log('Requester Dashboard (PHP/MySQL backend) initialised.');
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();
